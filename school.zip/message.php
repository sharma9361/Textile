<table class="message-table"  id="tblCustomers">
	<tr>
		<th>contact_id</th>
		<th>user_name</th>
		<th>user_email</th>
		<th>subject</th>
		<th>Message</th>
	</tr>
	<?php
	$conn=mysqli_connect("localhost","root","","db_fitn1");
	if($conn-> connect_error){
		die("connection failed:". $conn-> connect_error);
	}
	$sql="SELECT contact_id,user_name,user_email,subject,content from tb_fitn1";
	$result = $conn-> query($sql);
	

	if($result-> num_rows > 0) {
		while ($row = $result-> fetch_assoc()) {
			echo"<tr><td>".$row["contact_id"] ."</td><td>".$row["user_name"]."</td><td>".$row["user_email"]."</td><td>".$row["subject"]."</td><td>".$row["content"]."</td></tr>";
        }
		echo"</table>";
	}
	else {
		echo "0 result";
	}
	$conn-> close();
	?>

</table>

<input type="button" id="btnExport" value="Export" />
    <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.22/pdfmake.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/0.4.1/html2canvas.min.js"></script>
    <script type="text/javascript">
        $("body").on("click", "#btnExport", function () {
            html2canvas($('#tblCustomers')[0], {
                onrendered: function (canvas) {
                    var data = canvas.toDataURL();
                    var docDefinition = {
                        content: [{
                            image: data,
                            width: 500
                        }]
                    };
                    pdfMake.createPdf(docDefinition).download("cutomer-details.pdf");
                }
            });
        });
    </script>




<style type="text/css">
	.message-table{
		width: 70%;
		margin-left: 15%;
		margin-top: 5%;
		
		border: 5px solid;
	}
	.message-table td{
		border-bottom: 2px solid blueviolet;
		padding: 20px;
		text-align: center;
	}
	.message-table th{
		border: 2px solid;
		border-bottom: 5px solid;
		padding: 20px;
		text-align: center;
	}

</style>