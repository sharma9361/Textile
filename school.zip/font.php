<?php
if(!empty($_POST["send"])) {
    $name = $_POST["userName"];
    $email = $_POST["userEmail"];
    $subject = $_POST["subject"];
    $content = $_POST["content"];

    $toEmail = "shadowws@gmail.com";
     
    $mailHeaders = "From: " . $name . "<". $email .">\r\n";
    if(mail($toEmail, $subject, $content, $mailHeaders)) {
        $message = "Your contact information is received successfully.";
        $type = "success";
    }
}
require_once "font.php";
?>



  <?php
if(!empty($_POST["send"])) {
  $name = $_POST["userName"];
  $mail = $_POST["mail"];
  $subject = $_POST["subject"];
  $content = $_POST["content"];

  $conn = mysqli_connect("localhost", "root", "", "db_fitn1") or die("Connection Error: " . mysqli_error($conn));
  mysqli_query($conn, "INSERT INTO tomail (user_name, email,subject,content) VALUES ('" . $name. "', '" . $email. "','" . $subject. "','" . $content. "')");
  $insert_id = mysqli_insert_id($conn);
  
     $message = "Your contact information is saved successfully.";
     $type = "success";
  
}
require_once "font.php";
?>

<body>
    <div class="form-container">
        <form name="frmContact" id="" frmContact="" method="post"
            action="" enctype="multipart/form-data"
            onsubmit="return validateContactForm()">

            <div class="input-row">
                <label style="padding-top: 20px;">Name</label> <span
                    id="userName-info" class="info"></span><br /> <input
                    type="text" class="input-field" name="userName"
                    id="userName" />
            </div>
            <div class="input-row">
                <label>mail</label> <span id="userEmail-info"
                    class="info"></span><br /> <input type="text"
                    class="input-field" name="mail" id="mail" />
            </div>
            <div class="input-row">
                <label>Subject</label> <span id="subject-info"
                    class="info"></span><br /> <input type="text"
                    class="input-field" name="subject" id="subject" />
            </div>
            <div class="input-row">
                <label>Message</label> <span id="userMessage-info"
                    class="info"></span><br />
                <textarea name="content" id="content"
                    class="input-field" cols="60" rows="6"></textarea>
            </div>


                    
            
            <div>
                <input type="submit" name="send" class="btn-submit"
                    value="Send" />

                <div id="statusMessage"> 
                        <?php
                        if (! empty($message)) {
                            ?>
                            <p class='<?php echo $type; ?>Message'><?php echo $message; ?></p>
                        <?php
                        }
                        ?>
                    </div>
            </div>
        </form>
    </div>
